Installation:

1: Install Risugami's Modloader. If you don't know what that is, look it up on Google.
Follow the directions on his page to learn how to install mods. It will help you install this.
(1b: install Risugami's Audiomod if you want wall sound effect)
2: Open the Equivalent Exchange RAR file
3: Open your minecraft.jar file using WinRAR or suitable unzipping program.
4: Take the x3n0 and armor folders and ALL class files from the rar and drop them straight into your .jar file.
5: take the resources folder and merge it with the existing resources folder in your .minecraft directory
(this is only if you want wall sounds, and you must have audiomod)
That's all. Close all open rar/jar files and play the game.


