import java.util.ArrayList;
import java.util.Random;

public class ACPage {
	private static int nextID = 1;
	
	final int id;
	public final String title;
	ArrayList<Integer> list = new ArrayList<Integer>();
	
	public ACPage() {
		id = 0;
		title = "Minecraft";
		ACPages.pages.add(this);
	}
	public ACPage(String title) {
		id = nextID++;
		this.title = title;
		ACPages.pages.add(this);
	}
	
	public void addAchievements(nu... achievements) {
		for (nu achievement : achievements) list.add(achievement.e);
	}
	
	public int bgGetSprite(Random random, int x, int y) {
		int sprite = un.F.bm;
		int rnd = random.nextInt(1+y)+y/2;
		
		if (rnd > 37 || y == 35) sprite = un.A.bm;
		else if (rnd == 22) sprite = random.nextInt(2) == 0 ? un.ax.bm : un.aO.bm;
		else if (rnd == 10) sprite = un.I.bm;
		else if (rnd == 8) sprite = un.J.bm;
		else if (rnd > 4) sprite = un.u.bm;
		else if (rnd > 0) sprite = un.w.bm;
		
		return sprite;
	}
}