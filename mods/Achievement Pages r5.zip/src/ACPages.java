import java.util.ArrayList;

public class ACPages {
	public static int currentPage = 0;
	private static ArrayList<Integer> hidden = new ArrayList<Integer>();
	static ArrayList<ACPage> pages = new ArrayList<ACPage>();
	public static ACPage defaultPage = new ACPage();
	
	static {
		ModLoader.getLogger().info("[ACPages r5] Loaded.");
	}
	
	public static void hideAchievements(nu... achievements) {
		for (nu achievement : achievements) hidden.add(achievement.e);
	}
	public static boolean isHidden(nu achievement) {
		return hidden.contains(achievement.e);
	}
	
	public static ACPage getPage(nu achievement) {
		if (achievement == null) return null;
		for (ACPage Page : pages) {
			if (Page.list.contains(achievement.e)) return Page;
		}
		return defaultPage;
	}
	public static ACPage getCurrentPage() {
		return pages.get(currentPage);
	}
	
	public static String getCurrentPageTitle() {
		return getCurrentPage().title;
	}
	
	public static void pageNext() {
		currentPage++;
		if (currentPage > pages.size()-1) currentPage = 0;
	}
	public static void pagePrev() {
		currentPage--;
		if (currentPage < 0) currentPage = pages.size()-1;
	}
}