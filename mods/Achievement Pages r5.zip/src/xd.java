import java.util.ArrayList;
import java.util.Random;
import org.lwjgl.input.Mouse;
import org.lwjgl.opengl.GL11;

public class xd extends cy {
	private static final int s, t, u, v;
	protected int a, i, j, l;
	protected double m, n, o, p, q, r;
	private int w;
	private wz x;
	
	private boolean draw = true;

	public xd(wz wz1) {
		a = 256;
		i = 202;
		j = 0;
		l = 0;
		w = 0;
		x = wz1;
		char c1 = '\215';
		char c2 = '\215';
		m = o = q = en.f.a * 24 - c1 / 2 - 12;
		n = p = r = en.f.b * 24 - c2 / 2;
	}

	@SuppressWarnings("unchecked")
	public void b() {
		e.clear();
		e.add(new aa(1, c / 2 + 24, d / 2 + 74, 80, 20, dm.a("gui.done")));
		e.add(new aa(11, c / 2 -113, d / 2 + 74, 20, 20, "<"));
		e.add(new aa(12, c / 2 -93, d / 2 + 74, 20, 20, ">"));
	}

	protected void a(ka button) {
		if(button.f == 1) {
			b.a((cy)null);
			b.g();
		} else if (button.f == 11) ACPages.pagePrev();
		else if (button.f == 12) ACPages.pageNext();

		super.a(button);
	}

	protected void a(char c1, int i1) {
		if(i1 == b.z.r.b) {
			b.a((cy)null);
			b.g();
		} else {
			super.a(c1, i1);
		}
	}

	public void a(int i1, int j1, float f) {
		if(Mouse.isButtonDown(0)) {
			int k1 = (c - a) / 2;
			int l1 = (d - i) / 2;
			int i2 = k1 + 8;
			int j2 = l1 + 17;

			if((w == 0 || w == 1) && i1 >= i2 && i1 < i2 + 224 && j1 >= j2 && j1 < j2 + 155) {
				if(w == 0) {
					w = 1;
				} else {
					o -= i1 - j;
					p -= j1 - l;
					q = m = o;
					r = n = p;
				}

				j = i1;
				l = j1;
			}

			if (q < (double)s) q = s;
			if (r < (double)t) r = t;
			if (q >= (double)u) q = u - 1;
			if (r >= (double)v) r = v - 1;
		} else w = 0;

		i();
		b(i1, j1, f);
		GL11.glDisable(2896);
		GL11.glDisable(2929);
		k();
		GL11.glEnable(2896);
		GL11.glEnable(2929);
	}

	public void a() {
		m = o;
		n = p;
		double d = q - o;
		double d1 = r - p;

		if (d * d + d1 * d1 < 4D) {
			o += d;
			p += d1;
		} else {
			o += d * 0.84999999999999998D;
			p += d1 * 0.84999999999999998D;
		}
	}

	protected void k() {
		int i1 = (c - a) / 2;
		int j1 = (d - i) / 2;
		g.b("Achievements", i1 + 15, j1 + 5, 0x404040);
	}

	@SuppressWarnings("static-access")
	protected void b(int i1, int j1, float f) {
		int k1 = ik.b(m + (o - m) * (double)f);
		int l1 = ik.b(n + (p - n) * (double)f);

		if(k1 < s) k1 = s;
		if(l1 < t) l1 = t;
		if(k1 >= u) k1 = u - 1;
		if(l1 >= v) l1 = v - 1;

		int i2 = b.p.b("/terrain.png");
		int j2 = b.p.b("/achievement/bg.png");
		int k2 = (c - a) / 2;
		int l2 = (d - i) / 2;
		int i3 = k2 + 16;
		int j3 = l2 + 17;
		k = 0.0F;
		GL11.glDepthFunc(518);
		GL11.glPushMatrix();
		GL11.glTranslatef(0.0F, 0.0F, -200F);
		GL11.glEnable(3553);
		GL11.glDisable(2896);
		GL11.glEnable(32826);
		GL11.glEnable(2903);
		b.p.b(i2);
		int k3 = k1 + 288 >> 4;
		int i4 = l1 + 288 >> 4;
		int j4 = (k1 + 288) % 16;
		int i5 = (l1 + 288) % 16;
		Random random = new Random();

		for(int l8 = 0; l8 * 16 - i5 < 155; l8++) {
			float f5 = 0.6F - ((float)(i4 + l8) / 25F) * 0.3F;
			GL11.glColor4f(f5, f5, f5, 1.0F);

			for(int i9 = 0; i9 * 16 - j4 < 224; i9++) {
				random.setSeed(1234 + k3 + i9);
				random.nextInt();
				int k9 = ACPages.getCurrentPage().bgGetSprite(random,k3+i9,i4+l8);

				if (k9 != -1)
				b((i3 + i9 * 16) - j4, (j3 + l8 * 16) - i5, k9 % 16 << 4, (k9 >> 4) << 4, 16, 16);
			}
		}

		GL11.glEnable(2929);
		GL11.glDepthFunc(515);
		GL11.glDisable(3553);

		for(int l3 = 0; l3 < en.e.size(); l3++) {
			nu nu2 = (nu)en.e.get(l3);

			if(nu2.c == null) continue;

			int k4 = (nu2.a * 24 - k1) + 11 + i3;
			int j5 = (nu2.b * 24 - l1) + 11 + j3;
			int k5 = (nu2.c.a * 24 - k1) + 11 + i3;
			int i6 = (nu2.c.b * 24 - l1) + 11 + j3;
			int l6 = 0;
			boolean flag = x.a(nu2);
			boolean flag1 = x.b(nu2);
			char c1 = Math.sin(((double)(System.currentTimeMillis() % 600L) / 600D) * 3.1415926535897931D * 2D) <= 0.59999999999999998D ? '\202' : '\377';

			if(flag)
				l6 = 0xff707070;
			else if(flag1)
				l6 = 65280 + (c1 << 24);
			else
				l6 = 0xff000000;

			draw = isVisibleLine(nu2);
			a(k4, k5, j5, l6);
			b(k5, j5, i6, l6);
		}

		nu nu1 = null;
		ba ba1 = new ba();
		GL11.glPushMatrix();
		GL11.glRotatef(180F, 1.0F, 0.0F, 0.0F);
		((t)null).b();
		GL11.glPopMatrix();
		GL11.glDisable(2896);
		GL11.glEnable(32826);
		GL11.glEnable(2903);

		for(int l4 = 0; l4 < en.e.size(); l4++) {
			nu nu4 = (nu)en.e.get(l4);
			
			if (!isVisibleAchievement(nu4,1)) continue;
			
			int l5 = nu4.a * 24 - k1;
			int j6 = nu4.b * 24 - l1;

			if(l5 < -24 || j6 < -24 || l5 > 224 || j6 > 155)
				continue;

			if(x.a(nu4)) {
				float f1 = 1.0F;
				GL11.glColor4f(f1, f1, f1, 1.0F);
			} else if(x.b(nu4)) {
				float f2 = Math.sin(((double)(System.currentTimeMillis() % 600L) / 600D) * 3.1415926535897931D * 2D) >= 0.59999999999999998D ? 0.8F : 0.6F;
				GL11.glColor4f(f2, f2, f2, 1.0F);
			} else {
				float f3 = 0.3F;
				GL11.glColor4f(f3, f3, f3, 1.0F);
			}

			b.p.b(j2);
			int i7 = i3 + l5;
			int k7 = j3 + j6;

			if(nu4.f())
				b(i7 - 2, k7 - 2, 26, 202, 26, 26);
			else
				b(i7 - 2, k7 - 2, 0, 202, 26, 26);

			if(!x.b(nu4)) {
				float f4 = 0.1F;
				GL11.glColor4f(f4, f4, f4, 1.0F);
				ba1.a = false;
			}

			GL11.glEnable(2896);
			GL11.glEnable(2884);
			ba1.a(b.q, b.p, nu4.d, i7 + 3, k7 + 3);
			GL11.glDisable(2896);

			if(!x.b(nu4))
				ba1.a = true;

			GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);

			if(i1 >= i3 && j1 >= j3 && i1 < i3 + 224 && j1 < j3 + 155 && i1 >= i7 && i1 <= i7 + 22 && j1 >= k7 && j1 <= k7 + 22)
				nu1 = nu4;
		}

		GL11.glDisable(2929);
		GL11.glEnable(3042);
		GL11.glColor4f(1.0F, 1.0F, 1.0F, 1.0F);
		b.p.b(j2);
		b(k2, l2, 0, 0, a, i);
		GL11.glPopMatrix();
		k = 0.0F;
		GL11.glDepthFunc(515);
		GL11.glDisable(2929);
		GL11.glEnable(3553);
		super.a(i1, j1, f);

		if(nu1 != null) {
			nu nu3 = nu1;
			String s1 = nu3.f;
			String s2 = nu3.e();
			int k6 = i1 + 12;
			int j7 = j1 - 4;

			if(x.b(nu3)) {
				int l7 = Math.max(g.a(s1), 120);
				int j8 = g.a(s2, l7);

				if(x.a(nu3))
					j8 += 12;

				a(k6 - 3, j7 - 3, k6 + l7 + 3, j7 + j8 + 3 + 12, 0xc0000000, 0xc0000000);
				g.a(s2, k6, j7 + 12, l7, 0xffa0a0a0);

				if(x.a(nu3))
					g.a(dm.a("achievement.taken"), k6, j7 + j8 + 4, 0xff9090ff);
			} else {
				int i8 = Math.max(g.a(s1), 120);
				String s3 = dm.a("achievement.requires", new Object[] {
									 nu3.c.f
								 });
				int k8 = g.a(s3, i8);
				a(k6 - 3, j7 - 3, k6 + i8 + 3, j7 + k8 + 12 + 3, 0xc0000000, 0xc0000000);
				g.a(s3, k6, j7 + 12, i8, 0xff705050);
			}

			g.a(s1, k6, j7, x.b(nu3) ? nu3.f() ? -128 : -1 : nu3.f() ? 0xff808040 : 0xff808080);
		}

		GL11.glEnable(2929);
		GL11.glEnable(2896);
		((t)null).a();
		
		g.b(ACPages.getCurrentPageTitle(),(c/2-69),(d/2+80),0);
	}
	
	protected void a(int paramInt1, int paramInt2, int paramInt3, int paramInt4, int paramInt5) {
		int i;
		if (paramInt1 < paramInt3) {
			i = paramInt1;
			paramInt1 = paramInt3;
			paramInt3 = i;
		}
		if (paramInt2 < paramInt4) {
			i = paramInt2;
			paramInt2 = paramInt4;
			paramInt4 = i;
		}
		float f1 = (paramInt5 >> 24 & 0xFF) / 255.0F;
		float f2 = (paramInt5 >> 16 & 0xFF) / 255.0F;
		float f3 = (paramInt5 >> 8 & 0xFF) / 255.0F;
		float f4 = (paramInt5 & 0xFF) / 255.0F;
		ns localns = ns.a;
		GL11.glEnable(3042);
		GL11.glDisable(3553);
		GL11.glBlendFunc(770, 771);
		GL11.glColor4f(f2, f3, f4, f1);
		
		if (draw) {
			localns.b();
			localns.a(paramInt1, paramInt4, 0.0D);
			localns.a(paramInt3, paramInt4, 0.0D);
			localns.a(paramInt3, paramInt2, 0.0D);
			localns.a(paramInt1, paramInt2, 0.0D);
			localns.a();
		}
		
		GL11.glEnable(3553);
		GL11.glDisable(3042);
	}
	
	@SuppressWarnings("unchecked")
	public boolean isVisibleAchievement(nu achievement, int deep) {
		if (checkHidden(achievement)) return false;
		
		int tabID = ACPages.getPage(achievement).id;
		if (tabID == ACPages.currentPage) return true; else if (deep >= 1) {
			ArrayList<Object> list = new ArrayList<Object>(en.e);
			
			for (int i = 0; i < list.size(); i++) {
				nu tmpAc = (nu)list.get(i);
				if (tmpAc.e == achievement.e) {list.remove(i--); continue;}
				if (tmpAc.c == null) {list.remove(i--); continue;}
				if (tmpAc.c.e != achievement.e) {list.remove(i--); continue;}
			}
			
			for (int i = 0; i < list.size(); i++) {
				nu tmpAc = (nu)list.get(i);
				if (isVisibleAchievement(tmpAc,deep-1)) return true;
			}
		}
		return false;
	}
	
	public boolean isVisibleLine(nu achievement) {
		if (achievement.c != null) {
			if (isVisibleAchievement(achievement,1) && isVisibleAchievement(achievement.c,1)) return true;
		}
		return false;
	}
	
	public boolean checkHidden(nu achievement) {
		if (b.I.a(achievement)) return false;
		if (ACPages.isHidden(achievement)) return true;
		if (achievement.c == null) return false;
		return checkHidden(achievement.c);
	}

	public boolean c() {
		return true;
	}

	static  {
		s = en.a * 24 - 112;
		t = en.b * 24 - 112;
		u = en.c * 24 - 77;
		v = en.d * 24 - 77;
	}
}
