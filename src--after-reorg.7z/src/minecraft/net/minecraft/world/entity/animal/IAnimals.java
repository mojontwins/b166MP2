package net.minecraft.world.entity.animal;

public interface IAnimals {
}
