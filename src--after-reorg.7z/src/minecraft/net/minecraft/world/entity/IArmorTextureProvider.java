package net.minecraft.world.entity;

import net.minecraft.world.item.ItemStack;

public interface IArmorTextureProvider {
	String getArmorTextureFile(ItemStack var1);
}
