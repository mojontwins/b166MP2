package net.minecraft.world.entity;

import net.minecraft.world.entity.animal.IAnimals;

public interface INpc extends IAnimals {
}
