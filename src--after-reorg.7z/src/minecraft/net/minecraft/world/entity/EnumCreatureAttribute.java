package net.minecraft.world.entity;

public enum EnumCreatureAttribute {
	UNDEFINED,
	UNDEAD,
	ARTHROPOD;
}
