package net.minecraft.world.entity.monster;

public interface IMobWithLevel {
	public void setLevel(int level);

	public int getMaxLevel();
}
