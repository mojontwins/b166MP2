package net.minecraft.world.item;

public interface ITextureProvider {
	String getTextureFile();
}
