package net.minecraft.world.item;

public class ItemGolden extends Item {

	public ItemGolden(int i1) {
		super(i1);
	}

}
