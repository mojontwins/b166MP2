package net.minecraft.client.renderer;

import java.awt.image.BufferedImage;

public interface HttpTextureProcessor {
	BufferedImage process(BufferedImage bufferedImage1);
}
