package net.minecraft.client.player;

public class MovementInput {
	public float moveStrafe = 0.0F;
	public float moveForward = 0.0F;
	public boolean jump = false;
	public boolean sneak = false;

	public void readMovementInput() {
	}
}
