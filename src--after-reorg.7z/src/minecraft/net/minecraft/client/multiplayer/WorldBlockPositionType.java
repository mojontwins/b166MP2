package net.minecraft.client.multiplayer;

public class WorldBlockPositionType {
	public int posX;
	public int posY;
	public int posZ;
	public int acceptCountdown;
	public int blockID;
	public int metadata;
}
