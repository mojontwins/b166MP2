package net.minecraft.client.gui;

public class GuiMinimap extends GuiScreen {

}
