package net.minecraft.util;

public class MinecraftException extends RuntimeException {
	/**
	 * 
	 */
	private static final long serialVersionUID = 6933903242362850591L;

	public MinecraftException(String string1) {
		super(string1);
	}
}
