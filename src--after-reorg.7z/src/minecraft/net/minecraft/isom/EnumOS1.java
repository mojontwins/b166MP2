package net.minecraft.isom;

enum EnumOS1 {
	linux,
	solaris,
	windows,
	macos,
	unknown;
}
