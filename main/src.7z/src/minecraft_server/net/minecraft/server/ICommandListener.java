package net.minecraft.server;

public interface ICommandListener {
	void log(String string1);

	String getUsername();
}
