package net.minecraft.server;

public interface IUpdatePlayerListBox {
	void update();
}
