package net.minecraft.world.entity;

public interface ILiquid {

}
