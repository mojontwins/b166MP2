package net.minecraft.world.entity;

import net.minecraft.world.level.World;

public abstract class EntityWeatherEffect extends Entity {
	public EntityWeatherEffect(World world1) {
		super(world1);
	}
}
