package net.minecraft.world.entity;

public interface ISentient {

	// Entities which implement this interface will be attacked by zombies.
	
}
