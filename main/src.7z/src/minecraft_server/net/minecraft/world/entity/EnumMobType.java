package net.minecraft.world.entity;

public enum EnumMobType {
	everything,
	mobs,
	players;
}
