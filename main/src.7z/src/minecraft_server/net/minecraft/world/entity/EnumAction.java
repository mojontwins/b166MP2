package net.minecraft.world.entity;

public enum EnumAction {
	none,
	eat,
	drink,
	block,
	bow;
}
