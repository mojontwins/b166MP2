package net.minecraft.world.entity.monster;

import net.minecraft.world.entity.animal.IAnimals;

public interface IMob extends IAnimals {
}
