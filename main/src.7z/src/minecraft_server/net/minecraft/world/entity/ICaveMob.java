package net.minecraft.world.entity;

public interface ICaveMob {

}
