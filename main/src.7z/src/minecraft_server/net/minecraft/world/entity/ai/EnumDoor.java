package net.minecraft.world.entity.ai;

public enum EnumDoor {
	OPENING,
	WOOD_DOOR,
	GRATES,
	IRON_DOOR;
}
