package net.minecraft.world;

public class Version {

	public static String getVersion() {
		return "a1.1.3";
	}

}
