package net.minecraft.world.level.chunk.storage;

public interface IThreadedFileIO {
	boolean writeNextIO();
}
