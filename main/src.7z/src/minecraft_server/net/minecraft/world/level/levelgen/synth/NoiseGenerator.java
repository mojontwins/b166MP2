package net.minecraft.world.level.levelgen.synth;

public abstract class NoiseGenerator {
}
