package net.minecraft.world.level;

public class WeightedRandomChoice {
	protected int itemWeight;

	public WeightedRandomChoice(int i1) {
		this.itemWeight = i1;
	}
}
