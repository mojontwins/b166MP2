package net.minecraft.world.level.tile;

public interface IPlant {

}
