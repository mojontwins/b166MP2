package net.minecraft.world.level.tile;

import java.util.Random;

import net.minecraft.world.entity.DamageSource;
import net.minecraft.world.entity.Entity;
import net.minecraft.world.level.World;
import net.minecraft.world.level.creative.CreativeTabs;
import net.minecraft.world.level.material.Material;
import net.minecraft.world.phys.AxisAlignedBB;

public class BlockCactus extends Block {
	protected BlockCactus(int i1, int i2) {
		super(i1, i2, Material.cactus);
		this.setTickRandomly(true);
		this.displayOnCreativeTab = CreativeTabs.tabDeco;
	}

	public void updateTick(World world1, int i2, int i3, int i4, Random random5) {
		if(world1.isAirBlock(i2, i3 + 1, i4)) {
			int i6;
			for(i6 = 1; world1.getBlockId(i2, i3 - i6, i4) == this.blockID; ++i6) {
			}

			if(i6 < 3) {
				int i7 = world1.getBlockMetadata(i2, i3, i4);
				if(i7 == 15) {
					world1.setBlockWithNotify(i2, i3 + 1, i4, this.blockID);
					world1.setBlockMetadataWithNotify(i2, i3, i4, 0);
				} else {
					world1.setBlockMetadataWithNotify(i2, i3, i4, i7 + 1);
				}
			}
		}

	}

	public AxisAlignedBB getCollisionBoundingBoxFromPool(World world1, int i2, int i3, int i4) {
		float f5 = 0.0625F;
		return AxisAlignedBB.getBoundingBoxFromPool((double)((float)i2 + f5), (double)i3, (double)((float)i4 + f5), (double)((float)(i2 + 1) - f5), (double)((float)(i3 + 1) - f5), (double)((float)(i4 + 1) - f5));
	}

	public AxisAlignedBB getSelectedBoundingBoxFromPool(World world1, int i2, int i3, int i4) {
		float f5 = 0.0625F;
		return AxisAlignedBB.getBoundingBoxFromPool((double)((float)i2 + f5), (double)i3, (double)((float)i4 + f5), (double)((float)(i2 + 1) - f5), (double)(i3 + 1), (double)((float)(i4 + 1) - f5));
	}

	public int getBlockTextureFromSide(int i1) {
		return i1 == 1 ? this.blockIndexInTexture - 1 : (i1 == 0 ? this.blockIndexInTexture + 1 : this.blockIndexInTexture);
	}

	public boolean renderAsNormalBlock() {
		return true;
	}

	public boolean isOpaqueCube() {
		return true;
	}

	public boolean canPlaceBlockAt(World world1, int i2, int i3, int i4) {
		return !super.canPlaceBlockAt(world1, i2, i3, i4) ? false : this.canBlockStay(world1, i2, i3, i4);
	}

	public void onNeighborBlockChange(World world1, int i2, int i3, int i4, int i5) {
		if(!this.canBlockStay(world1, i2, i3, i4)) {
			this.dropBlockAsItem(world1, i2, i3, i4, world1.getBlockMetadata(i2, i3, i4), 0);
			world1.setBlockWithNotify(i2, i3, i4, 0);
		}

	}

	public boolean canBlockStay(World world1, int i2, int i3, int i4) {
		if(world1.getBlockMaterial(i2 - 1, i3, i4).isSolid()) {
			return false;
		} else if(world1.getBlockMaterial(i2 + 1, i3, i4).isSolid()) {
			return false;
		} else if(world1.getBlockMaterial(i2, i3, i4 - 1).isSolid()) {
			return false;
		} else if(world1.getBlockMaterial(i2, i3, i4 + 1).isSolid()) {
			return false;
		} else {
			Block block = world1.getBlock(i2, i3 - 1, i4);
			return block != null && block.canGrowCacti();
		}
	}

	public void onEntityCollidedWithBlock(World world1, int i2, int i3, int i4, Entity entity5) {
		entity5.attackEntityFrom(DamageSource.cactus, 1);
	}
	
	public boolean canGrowCacti() {
		return true;
	}
}
