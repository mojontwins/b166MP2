package net.minecraft.world.level;

public interface ISurface {

}
