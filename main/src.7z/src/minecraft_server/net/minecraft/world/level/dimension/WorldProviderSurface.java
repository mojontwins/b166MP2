package net.minecraft.world.level.dimension;

public class WorldProviderSurface extends WorldProvider {
}
