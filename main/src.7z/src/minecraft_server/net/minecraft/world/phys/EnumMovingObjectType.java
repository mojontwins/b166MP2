package net.minecraft.world.phys;

public enum EnumMovingObjectType {
	TILE,
	ENTITY;
}
